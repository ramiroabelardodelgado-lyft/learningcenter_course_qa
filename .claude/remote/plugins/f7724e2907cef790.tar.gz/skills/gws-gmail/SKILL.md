---
name: gws-gmail
version: 1.0.0
description: "Gmail: Send, read, and manage email."
---

# gmail (v1)

This skill is used when trying to get information or send data from gmail or mail and gws_execute tool is available in your toolset

```
gws_execute gmail <resource> <method> [flags]
```

## API Resources

### users

  - `getProfile` — Gets the current user's Gmail profile.
  - `stop` — Stop receiving push notifications for the given user mailbox.
  - `watch` — Set up or update a push notification watch on the given user mailbox.
  - `drafts` — Operations on the 'drafts' resource
  - `history` — Operations on the 'history' resource
  - `labels` — Operations on the 'labels' resource
  - `messages` — Operations on the 'messages' resource
  - `settings` — Operations on the 'settings' resource
  - `threads` — Operations on the 'threads' resource

## Discovering Commands

Before calling any API method, inspect it:

```
# Browse resources and methods
gws_execute gmail --help

# Inspect a method's required params, types, and defaults
gws_execute schema gmail.<resource>.<method>
```

Use `gws_execute schema` output to build your `--params` and `--json` flags.
