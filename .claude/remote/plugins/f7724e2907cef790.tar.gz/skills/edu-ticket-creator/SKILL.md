---
name: edu-ticket-creator
description: Creates Jira tickets from a Lyft EDU Tutorial Spec Google Doc and logs everything to CSV files in Google Drive. Use this skill whenever someone asks to create Jira tickets from a tutorial spec, kickoff a new tutorial project in Jira, generate tickets from a Google Doc, or automate EDU ticket creation. Also triggers on phrases like "create tickets for [project]", "set up Jira for this tutorial", "generate tickets from the spec", "kickoff [tutorial name]", or "--preview/--test a spec". Always use this skill when the Educational Content team needs to create or check a batch of Jira tickets from a tutorial spec document.
---

# EDU Ticket Creator

Creates a full Jira ticket hierarchy from a Lyft EDU Tutorial Spec Google Doc,
then logs results to CSV files in Google Drive (one master log + one per project).

## Ticket structure

```
Epic  (the whole tutorial project)
└── Task: Tutorial 1 – <n>
    └── Sub-task: [Page 1.1] <title> – Copy          (every page, always)
    └── Sub-task: [Page 1.1] <title> – Image         (visual = photo/image)
    └── Sub-task: [Page 1.1] <title> – Video         (visual = video/animation)
    └── Sub-task: [Page 1.1] <title> – UI Walkthrough  (visual = UI screenshot/showing)
└── Task: Tutorial 2 – <n>
    └── ...
```

---

## Step 1 — Determine mode and collect inputs

### Modes

| Flag / phrase | Mode | Jira | CSV logging |
|---|---|---|---|
| `--preview` or `--test` | Preview only | ✗ none | ✗ none |
| _(default)_ | Full run | ✓ creates tickets | ✓ logs to Drive |

### Required inputs

- **Google Doc URL** — the filled tutorial spec (not the blank template)
- **Epic title** — e.g. `[Driver EDU] Safety Refresher Tutorial`
- **Jira project key** — default `EDU`

### First-time setup (ask once, remember for the session)

- **Jira PAT (Personal Access Token)** — required to create tickets on `jira.lyft.net`.
  Ask: *"Paste your Jira Personal Access Token. You can generate one at jira.lyft.net → Profile → Personal Access Tokens."*
  Store it in memory for the session only. Never echo it back or include it in output.
  Use it as a Bearer token on all Jira REST API calls: `Authorization: Bearer <PAT>`

  > ⚠️ Do NOT use the Atlassian MCP connector — `jira.lyft.net` is Jira Data Center (on-prem),
  > not Atlassian Cloud. The MCP will fail with a cloud ID error. Use direct REST API calls instead.
  > See `references/jira-config.md` for all endpoint and payload details.

- **EDU master log folder ID** — the shared Drive folder where `EDU Kickoff Master Log.csv` lives.
  If the file doesn't exist yet, offer to create it. Ask for the folder ID (from the URL after `/folders/`).

---

## Step 2 — Read the Google Doc

Use **Google Drive connector** (`Google Drive:read_file_content`).
Extract the file ID from between `/document/d/` and `/edit` in the URL.

Also call `Google Drive:get_file_metadata` on the doc to get its **parent folder ID** —
needed to place the project CSV in the same folder.

---

## Step 3 — Parse the tutorial structure

Read the **Outline section(s) only** — stop before any "Copy & Mock" table.

For each `Tutorial X Outline:` heading:
- Extract the tutorial name, strip `[bracketed notes]` and asterisks
- Number sequentially: `Tutorial 1 – <n>`, `Tutorial 2 – <n>`

For each page row (`Page 1.1`, `Page 1.2`, etc.):
- Extract page number and title (strip asterisks)
- Detect visual type from the `Visual:` field:

| What appears after "Visual:" | Subtask type |
|---|---|
| Photo of... / Image of... | `Image` |
| Video / Animation | `Video` |
| UI screenshot / UI showing / UI of... / UI walkthrough | `UI Walkthrough` |
| Nothing / TBD / not mentioned | none — Copy subtask only |

---

## Step 4 — If --preview or --test: show and stop

Show the full ticket tree (same format as Step 6) then stop completely.
No Jira calls. No CSV writes. End with:

```
Preview only — no tickets were created or logged.
Run without --preview to do a full kickoff.
```

---

## Step 5 — Check Jira for existing tickets

Search for a matching Epic using the REST API (see `references/jira-config.md`):
```
project = EDU AND issuetype = Epic AND summary ~ "<epic title>"
```

### If a matching Epic is found

For each expected subtask, check if it already exists. Classify as:
- ✓ exists → skip
- ✗ missing → will create
- ~ title changed → flag for manual review, don't auto-update

Show the result:
```
⚠️  Found an existing kickoff (Feb 20, 2026)

  Epic:  EDU-1990  Waymo Tutorial  (In Progress)
  28 already exist · 3 missing · 1 changed

What would you like to do?
  1. Create only the missing tickets (3)
  2. Fresh run — new Epic + all tickets
  3. Cancel
```

### If no match found

```
No existing tickets found. This looks like a fresh kickoff.
```

---

## Step 6 — Show full preview and wait for approval

**Do NOT create any tickets or write any CSVs yet.**

Show the complete ticket tree with status indicators:

```
📋 Epic: [Driver EDU] Safety Refresher Tutorial

  📁 Tutorial 1 – Understanding Safe Driving Practices  (6 pages)
      ✗ [Page 1.1] Welcome to Safety Refresher – Copy        will be created
      ✗ [Page 1.1] Welcome to Safety Refresher – Image       will be created
      ✗ [Page 1.2] Staying Alert on the Road – Copy          will be created
      ✗ [Page 1.2] Staying Alert on the Road – UI Walkthrough  will be created
      ...

  📁 Tutorial 2 – Navigating Challenging Conditions  (5 pages)
      ...

────────────────────────────────────────────────────
0 already exist · 19 will be created · 0 changed

Also logging this run to:
  📄 Master log:    EDU Kickoff Master Log.csv  (EDU shared folder)
  📄 Project log:   [Driver EDU] Safety Refresher Tutorial – Ticket Log.csv  (same folder as spec)

Ready to proceed? Reply yes to create tickets,
or tell me anything you'd like to change first.
```

**Only proceed to Step 7 after explicit yes from the user.**

---

## Step 7 — Create tickets in Jira

Read `references/jira-config.md` for exact field IDs, endpoint URLs, and payload formats.

### Creation order

1. **Epic** — only if fresh run. Capture its key.
2. **Tasks** — one per tutorial, linked to Epic via `customfield_11100`.
3. **Sub-tasks** — missing ones only. Copy first, then Visual.

### Error handling

- One failure → log it, continue with the rest
- Epic Link rejected → retry with `customfield_14100` (Parent Link)
- Track each ticket: key, summary, type, tutorial, page, subtask type, status, error if any

---

## Step 8 — Write CSV logs

Read `references/sheets-config.md` for exact CSV column structure and Drive upload instructions.

### 8a — Master log (`EDU Kickoff Master Log.csv`)

1. Search for the file in the EDU shared folder by name
2. If found: download, decode, append new Runs row
3. If not found: create with header row + this run's row
4. Upload back to the EDU shared folder

Append **one row to the Runs section** with: date, time, epic title, epic key, doc URL, run by, mode, counts, Jira link, project log link.

### 8b — Project log (`<Epic title> – Ticket Log.csv`)

1. Search for the file in the spec doc's parent folder
2. If found: download, decode, append new rows
3. If not found: create with header rows + this run's data
4. Upload back to same folder as spec doc

Append **one Runs row** + **one Tickets row per ticket** (all tickets — existing and new).

### If CSV logging fails

Do NOT fail the whole run. Instead:
- Report the Jira results as normal
- Print the CSV rows in chat so the user can save them manually
- Note: "CSV logging failed — rows printed above for manual saving"

---

## Step 9 — Report results

```
✅ Done!

Created (19):
  EDU-2055  [Page 1.1] Welcome to Safety Refresher – Copy
  EDU-2056  [Page 1.1] Welcome to Safety Refresher – Image
  ... (17 more)

📄 Logged to:
  Master log:   https://drive.google.com/file/d/<id>  (EDU Kickoff Master Log.csv)
  Project log:  https://drive.google.com/file/d/<id>  ([Driver EDU] Safety Refresher Tutorial – Ticket Log.csv)

Epic: https://jira.lyft.net/browse/EDU-2050
```

---

For Jira field IDs → `references/jira-config.md`
For CSV structure and Drive upload instructions → `references/sheets-config.md`
