---
name: lyft-google-doc-styling
description: Comprehensive Lyft brand guidelines for creating Google Docs and Word documents including typography, colors, charts, and table formatting. Use when creating 'Google Docs,' 'Google Doc,' 'document,' 'doc,' 'Word document,' 'report,' or any Lyft-branded written content. DO NOT use for PowerPoint, Google Slides, presentations, decks, or slide decks (these have a separate skill). Ensures consistent Lyft branding with proper typography (Inter Tight/Inter), color palette (Lyft Medium Pink, Black Cherry), and standard layouts for charts and tables within documents.
---

# Lyft Google Doc Styling

## Overview

This skill ensures all Lyft Google Docs and Word documents follow official brand guidelines. Apply these standards automatically for any Lyft document creation including reports, memos, and documents with charts and tables.

## When to Use This Skill

Apply Lyft branding in these scenarios:
- Creating Google Docs
- Creating Word documents
- Creating reports or memos
- Designing charts within documents (column, pie, line charts)
- Creating tables with data in documents
- Any request mentioning "Google Doc," "document," "doc," "Word," or "report" in Lyft context

## When NOT to Use This Skill

Do NOT apply this skill for:
- PowerPoint presentations
- Google Slides presentations
- Keynote presentations
- Any request mentioning "presentation," "slides," "deck," "slide deck," or "PowerPoint"
- These presentation formats have a separate dedicated skill

## Typography Standards

### Heading 1
- Font: Inter Tight, 20pt, #cf0090 (Lyft Medium Pink)
- Use for: Main document titles, primary headers

### Heading 2
- Font: Inter Tight, 16pt, #1d0c17 (Black Cherry)
- Use for: Major section headers

### Heading 3
- Font: Inter Tight, 14pt, #820076 (Purple)
- Use for: Subsection headers

### Heading 4
- Font: Inter Tight, 11pt, #31222a (Gray 700)
- Use for: Minor subsection headers

### Subtitle
- Font: Inter, 11pt, #5c4d53 (Gray 600)
- Use for: Supporting text under titles

### Normal Text
- Font: Inter, 11pt, #1d0c17 (Black Cherry)
- Use for: Body text and paragraphs

## Color Palette

### Primary Colors
- **Medium Pink**: #cf0090 (Primary brand, highlights)
- **Black Cherry**: #1d0c17 (Primary text)
- **Purple**: #820076 (Accent color)

### Gray Scale
- **Gray 700**: #31222a
- **Gray 600**: #5c4d53
- **Gray 500**: #746a6d
- **Gray 400**: #91888b
- **Gray 300**: #b9b2b4
- **Gray 200**: #cfcbcc
- **Gray 100**: #e7e5e5
- **Off White**: #f1f0ec

### Secondary Palette (Use Sparingly)
- Yellow/Gold: #f5a623
- Orange-Red: #ff5722
- Blue: #6b9bd6

## Chart Design (for charts within documents)

### Column Charts
```
Use secondary palette colors:
- Period 1: Yellow/Gold (#f5a623)
- Period 2: Orange-Red (#ff5722)
- Period 3: Blue (#6b9bd6)

Chart title: Inter Tight, Gray 600 (#5c4d53)
Axis labels: Inter, Gray 600 (#5c4d53)
Note: Use secondary palette sparingly
```

### Pie Charts
```
Strategy: Highlight specific data with Medium Pink (#cf0090) or Purple (#820076)
Background segments: Gray values (#e7e5e5, #b9b2b4, #cfcbcc)

Use case: Medium Pink/Purple in midst of Gray to emphasize key data
Include: Percentages with segment labels
```

### Line Charts
```
For 3 or fewer data series:
- Series 1: Medium Pink (#cf0090)
- Series 2: Purple (#820076)
- Series 3: Light Pink/Gray blend

For more than 3 series:
- Use expanded Pink, Tan, Gray palettes
- Maintain brand consistency
- Avoid straying from brand colors
```

### Chart Best Practices
- Always use Medium Pink (#cf0090) for primary highlights
- Use gray values for supporting data
- Keep designs clean with minimal gridlines
- Expanded palette for complex data while maintaining brand alignment

## Table Design

### Standard Options

**Option 1: Gray Header (Minimal)**
```
Header: Gray 100 (#e7e5e5) background, Black Cherry (#1d0c17) text
Body: White background, no borders
Clean, modern look
```

**Option 2: Gray Header with Borders**
```
Header: Gray 100 (#e7e5e5) background
Body: White with Gray 300 (#b9b2b4) borders
More defined structure
```

**Option 3: Pink Headers**
```
Header: Medium Pink (#cf0090) text on white
Body: White background
Strong visual hierarchy
```

**Option 4: Pink Headers with Alternating Rows**
```
Header: Medium Pink (#cf0090) text
Body: Alternating white and Gray 100 (#e7e5e5)
Best for larger tables
```

### Invisible Tables for Key Metrics

**Purpose**: Highlight important numbers without visible table borders

**How to Create**:
1. Create table structure
2. Select entire table
3. Set border width to 0pt (More > Border width > 0pt)

**Styling**:
- Large numbers: 40-60pt, Medium Pink (#cf0090), bold
- Descriptive text: 11-14pt, Black Cherry (#1d0c17)
- Examples: $1.3M, 21%, 4/5

**Use Cases**:
- Projected revenue
- Growth percentages
- Market opportunity
- KPIs and executive summaries

## Implementation Guidelines

### For HTML-based Documents
When creating HTML documents, use these style definitions:

```html
<style>
  body {
    font-family: 'Inter', sans-serif;
    font-size: 11pt;
    color: #1d0c17;
    line-height: 1.6;
  }
  
  h1 {
    font-family: 'Inter Tight', sans-serif;
    font-size: 20pt;
    color: #cf0090;
  }
  
  h2 {
    font-family: 'Inter Tight', sans-serif;
    font-size: 16pt;
    color: #1d0c17;
  }
  
  h3 {
    font-family: 'Inter Tight', sans-serif;
    font-size: 14pt;
    color: #820076;
  }
  
  h4 {
    font-family: 'Inter Tight', sans-serif;
    font-size: 11pt;
    color: #31222a;
  }
  
  .subtitle {
    font-family: 'Inter', sans-serif;
    font-size: 11pt;
    color: #5c4d53;
  }
</style>
```

### For Google Docs
1. Set default font to Inter, 11pt, #1d0c17
2. Apply heading styles using Inter Tight as specified
3. Use Medium Pink (#cf0090) for titles and highlights
4. Reference brand-guidelines.md for complete specifications

### For Word Documents
- Import Inter and Inter Tight fonts
- Set up document styles with Lyft color palette
- Apply typography hierarchy consistently
- Use style templates for charts and tables

## Content Structure Best Practices

1. Start with Heading 1 for main document title
2. Use Heading 2 for primary sections
3. Use Heading 3 for subsections
4. Use Heading 4 for minor divisions
5. Apply subtitle style for supporting information
6. Maintain consistent hierarchy throughout

## Quick Reference

For complete specifications, see `references/brand-guidelines.md` which includes:
- Detailed typography specifications
- Complete color palette with hex codes
- Chart design guidelines with examples
- Table styling options
- Invisible tables technique
- Font family usage guidelines
