# Lyft Brand Style Specifications

This document contains the official Lyft brand style specifications for documents, presentations, and charts.

## Typography Specifications

### Heading 1
- **Font**: Inter Tight
- **Size**: 20pt
- **Color**: #cf0090 (Lyft Medium Pink)
- **Use case**: Main document titles, primary section headers

### Heading 2
- **Font**: Inter Tight
- **Size**: 16pt
- **Color**: #1d0c17 (Black Cherry)
- **Use case**: Major section headers

### Heading 3
- **Font**: Inter Tight
- **Size**: 14pt
- **Color**: #820076 (Purple)
- **Use case**: Subsection headers

### Heading 4
- **Font**: Inter Tight
- **Size**: 11pt
- **Color**: #31222a (Gray 700)
- **Use case**: Minor subsection headers

### Subtitle
- **Font**: Inter
- **Size**: 11pt
- **Color**: #5c4d53 (Gray 600)
- **Use case**: Document subtitles, supporting text under titles

### Normal Text
- **Font**: Inter
- **Size**: 11pt
- **Color**: #1d0c17 (Black Cherry)
- **Use case**: Body text, paragraphs, regular content

## Complete Color Palette

### Main Palette

**Primary Brand Colors:**
- **Black Cherry**: #1d0c17 (Primary text and headers)
- **Purple**: #820076 (Accent color, Heading 3)
- **Medium Pink**: #cf0090 (Primary brand color, Heading 1)

**Neutrals:**
- **Off White**: #f1f0ec (Backgrounds)
- **Gray 700**: #31222a (Dark gray, Heading 4)
- **Gray 600**: #5c4d53 (Medium gray, Subtitle)
- **Gray 500**: #746a6d
- **Gray 400**: #91888b
- **Gray 300**: #b9b2b4
- **Gray 200**: #cfcbcc
- **Gray 100**: #e7e5e5 (Light gray)

### Secondary Palette

Use sparingly for additional visual variety in charts:
- **Yellow/Gold**: #f5a623 (for column charts)
- **Orange-Red**: #ff5722 (for column charts)
- **Blue**: #6b9bd6 (for column charts)

### Expanded Palette

For charts with more data points than the main palette can represent, use variations of Pink, Tan, and Gray to maintain brand consistency.

## Chart Design Guidelines

### Column Charts
- Use the secondary palette (Yellow/Gold, Orange-Red, Blue) for data series
- Secondary palette should be used sparingly
- Keep charts clean with minimal gridlines
- Use Gray 600 (#5c4d53) for axis labels and titles
- Maintain consistent bar spacing

### Pie Charts
- Use gray values for most segments
- Highlight specific data with Medium Pink (#cf0090) or Purple (#820076)
- This creates visual emphasis on key information
- Include percentages with segment labels
- Strategy: Use Medium Pink/Purple in the midst of Gray values to highlight specific data

### Line Charts
- Use Pink/Purple gradient for multiple data series:
  - Period 1: Medium Pink (#cf0090)
  - Period 2: Purple (#820076)  
  - Period 3: Light Pink/Gray blend
- For more than 3 lines, use the expanded Pink, Tan, and Gray palettes
- Maintain brand consistency even with multiple data series
- Best practice: Prefer Pink, Tan, and Gray palettes to stay inline with brand guidelines

### Chart Best Practices
- Always use Medium Pink (#cf0090) as the primary highlight color
- Use gray values for supporting/background data
- Keep color schemes aligned with brand guidelines
- The expanded palette will be used when there are more data than the main palette can present
- Prefer Pink, Tan, and Gray palettes over other colors for brand consistency

## Table Design Options

### Standard Table Styles

**Option 1: Gray Header**
- Header row: Gray 100 (#e7e5e5) background
- Body rows: White background
- Text: Black Cherry (#1d0c17)
- No visible borders

**Option 2: Gray Header with Borders**
- Header row: Gray 100 (#e7e5e5) background
- Body rows: White with visible borders
- Creates more defined structure
- Use light gray borders (Gray 300)

**Option 3: Minimal Borders**
- Header row: Gray 100 (#e7e5e5) background
- Body rows: White with light borders
- Clean, modern appearance
- Subtle separation between cells

**Option 4: Pink Headers**
- Header row: Medium Pink (#cf0090) text on white background
- Body rows: White background
- More prominent visual hierarchy
- Use for emphasis

**Option 5: Pink Headers with Alternating Rows**
- Header row: Medium Pink (#cf0090) text on white
- Alternating row colors using Gray 100 (#e7e5e5)
- Improves readability for larger tables

### Invisible Tables Technique

Use invisible tables (0pt borders) to highlight important metrics and key numbers.

**Purpose**: Highlight significant information like projected revenue, growth percentages, and market opportunities.

**How to Create:**
1. Create a table structure
2. Highlight the entire table
3. Go to toolbar > More button (kebab menu)
4. Find "Border width" and select 0pt

**Styling Guidelines:**
- Use large, bold numbers in Medium Pink (#cf0090)
- Font size: 40-60pt for primary metrics
- Include supporting descriptive text below in Black Cherry (#1d0c17)
- Font size for descriptions: 11-14pt
- Maintain consistent spacing between metrics

**Use Cases:**
- Projected revenue: $1.3M, $6M, $510K
- Growth metrics: 21%, 3.1M
- Market opportunity: 4/5
- Key performance indicators
- Executive summary highlights

**Example Layout:**
```
$1.3M
Sed ut perspiciatis unde omnis iste
natus error sit voluptatem accusantium
doloremque laudantium

$6M
totam rem aperiam, eaque ipsa quae ab
illo inventore veritatis et quasi architecto

$510K
Nemo enim ipsam voluptatem quia
voluptas sit aspernatur aut odit aut fugit,
sed quia consequuntur magni dolores
```

## Font Families

- **Inter Tight**: Used for all headings (Heading 1-4), chart titles, and emphasis
- **Inter**: Used for normal text, subtitles, body content, and descriptive text
