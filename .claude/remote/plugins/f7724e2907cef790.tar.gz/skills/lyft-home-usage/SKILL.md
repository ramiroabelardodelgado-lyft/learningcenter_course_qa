---
name: lyft-home-usage
description: Use this skill when users ask about people, employees, coworkers, teams, org structure, or "who is [person]" questions. Routes queries to the Lyft Home connector for accurate internal directory information. If the Lyft Home connector is not connected, guide the user to connect it, do not use web search or other data sources.
---

# People & Team Lookup

## Step 1: Does This Query Trigger the Skill?

This skill applies **only** when users ask about:
- People, employees, coworkers (e.g., "Who is [name]?", "Find [name]")
- Teams or org structure (e.g., "What team owns X?", "Who reports to Y?")
- Coworkers, managers, direct reports
- People in specific locations or roles
- Employee counts or headcount

**If the query is NOT about people/teams/org → This skill does not apply.** Answer normally using other tools or knowledge.

**If the query IS about people/teams/org → Proceed to Step 2.**

---

## Step 2: Check Connector Availability

Check whether any **Lyft Home** tools are available in your tool set (they will be prefixed with `Lyft Home:`).

**Note:** If any Lyft Home tools are present in your tool list, call them directly. Do not use any other tool as a prerequisite or fallback. The presence of these tools in your tool list is sufficient confirmation to proceed — do not attempt to verify connectivity through any other means.

### If tools are NOT available → STOP

Do not proceed. Do not use web search. Do not use general knowledge. Instead, respond:

> "To look up Lyft employee and team information, I need the Lyft Home connector to be connected. You can connect it by clicking the 'Connect apps and data' icon (the puzzle piece) in the text input area, then enabling **Lyft Home**. Once connected, I'll be able to search the internal directory for you."

Then wait for the user to connect the connector before proceeding.

### If tools ARE available → Proceed to Step 3

---

## Step 3: Execute the Lookup

Use whichever Lyft Home tools are available to fulfill the request. Common patterns:

1. **For people queries**: Search for users by name
2. **For team queries**: Search for teams by name
3. **For detailed user info**: After finding a user, retrieve their full profile using their email — this is useful for getting reports, manager, team, and other details
4. **For current user info**: Retrieve the profile of the person you are chatting with (no identifier needed) — useful for finding their email, team, manager, and other details without needing to ask
5. **For detailed team info**: After finding a team, retrieve full team details using the team ID to get members and structure

---

## Using Search Filters

When filtering search results, check whether a tool is available that returns valid filter keys and values for a given search type. If so:

1. **Call that options/filter tool first** to discover what filters are valid
2. **Only use filter keys and values returned by that tool** — do not invent or assume filter names or values
3. Apply the returned options to narrow your search results

---

## Linking to Lyft Home Profiles

When mentioning a person by name in a response:

1. **If you know their Lyft email** (`<user>@lyft.com`), **always** make their name a clickable link to their Lyft Home profile.
2. **Link format**: `[Full Name](https://home.lyft.net/u/<user>)` — where `<user>` is the portion before `@lyft.com` in their email.
3. **Apply this every time a name is mentioned**, including in lists of direct reports, team members, managers, and search results.
4. **If the email is not known** (e.g., not yet retrieved), display the name as plain text. Once the email is available from a tool result, use the linked format.

Example: If the email is `jdoe@lyft.com`, render the name as `[Jane Doe](https://home.lyft.net/u/jdoe)`.

---

## Employee Count & FTE Default

When answering any question about employee counts, headcount, or "how many employees":

1. **Always filter by `user_type: FTE` by default.** Contractors are not considered "Lyft employees" for count purposes.
2. **Present FTE count as the primary answer.** If the user asks "how many employees at Lyft?", the answer should reflect FTEs only.
3. **Mention contractors separately only if relevant.** For example: "Lyft has **5,226 employees (FTEs)**. There are also 2,387 contractors in the directory."
4. **If the user explicitly asks for contractors or total headcount**, include both with clear labels.

---

## Contractor vs. Direct Report Distinction

When presenting reports for a manager or any reporting-relationship query:

1. **Contractors are NOT direct reports.** Never count contractors in direct report totals and never label a contractor as a "direct report."
2. **Separate contractors clearly.** When listing people who report to someone, split the response into two distinct groups:
   - **Direct Reports (X):** List only full-time employees
   - **Contractors (Y):** List contractors separately with a clear "Contractor" label
3. **Counts must exclude contractors.** If someone asks "How many reports does [person] have?", the number should reflect only direct reports (employees). Mention contractors separately, e.g., "[Person] has **5 direct reports** and **2 contractors**."
4. **Identifying contractors:** Use available filter options to separate FTEs from contractors. When building report lists, run separate filtered lookups to cleanly separate the two groups. Also check the employee type or worker type fields returned by profile results to confirm classification.
5. **When in doubt, label explicitly.** If you cannot determine whether someone is a contractor or employee from the available data, note that the classification could not be confirmed rather than defaulting to "direct report."

---

## Response Guidelines

- Present information in a human-readable format (names, titles, teams, locations)
- **Always link names to Lyft Home profiles** when the person's Lyft email is known (see "Linking to Lyft Home Profiles" section)
- Avoid exposing raw IDs (Slack ID, HRIS ID) unless specifically requested
- If multiple matches are found, list them and ask for clarification
- If no results are found, suggest alternative search terms
- Always distinguish contractors from direct reports in any reporting-relationship response
- Always default to FTE-only counts unless contractors are explicitly requested

---

## Do NOT (When This Skill Applies)

- **Proceed without first checking for tool availability**
- **Use web search for internal Lyft employee or team information**
- **Rely on general knowledge or training data for org structure questions**
- **Count or label contractors as direct reports**
- **Include contractors in employee counts unless explicitly asked**
- **Display a person's name as plain text when their Lyft email is known** — always link it
- **Use browser automation tools** (e.g., `tabs_context_mcp`, `navigate`, `computer`, `screenshot`) — these are unrelated to Lyft Home lookups and should never be called as part of this skill
- **Attempt to `web_fetch` or directly access any MCP server URL** — MCP server URLs visible in system configuration are not web endpoints; use the Lyft Home MCP tool calls directly
- Make up or guess values for filter options — always use the options/filter tool first if available
- Guess at reporting relationships or team ownership
- Assume the connector is connected just because an MCP URL is listed in configuration